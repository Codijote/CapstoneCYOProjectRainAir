#' ---
#' title: "Capstone Project, Choose your own project (CYO), Air quality in PM10 levels after rain in Budapest, Hungary, from 2003 until 2012"
#' author: "Navarro H Daniel D"
#' date: "2024-Mar-13"
#' output:
#'   pdf_document: default
#'   html_document:
#'     df_print: paged
#' ---
#' 
## ----setup, include=FALSE--------------------------------------------------------------------------------------
knitr::opts_chunk$set(warning = FALSE, message = FALSE,
                      fig.align="center", out.width="70%")

#' 
#' <!-- Start setting working directory: setwd("Capstone/CYOProjectRainForest") -->
#' 
## ----Data sources and packages load, echo=FALSE, results='hide'------------------------------------------------
# have rain data yearly from 2002 until 2023
# Main directory
# https://odp.met.hu/climate/observations_hungary/daily_rain/historical/
# File used
# https://odp.met.hu/climate/observations_hungary/daily_rain/historical/HABP_1RD_34413_20020101_20231231_hist.zip
# using linux command line downloaded all .zip file of 2002 until 2023
# unzipped with unzip
# merged all .csv files from command line

# Air quality in Europe, parquet database
# https://www.eea.europa.eu/en/datahub/datahubitem-view/778ef9f5-6293-4846-badd-56a29c70880d

# loading or installing when needed the working packages
if(!require(tidyverse)) install.packages("tidyverse", repos = "http://cran.us.r-project.org")
if(!require(caret)) install.packages("caret", repos = "http://cran.us.r-project.org")
if(!require(gridExtra)) install.packages("gridExtra", repos = "http://cran.us.r-project.org")
if(!require(dslabs)) install.packages("dslabs", repos = "http://cran.us.r-project.org")
if(!require(ggplot2)) install.packages("ggplot2", repos = "http://cran.us.r-project.org")
if(!require(dplyr)) install.packages("dplyr", repos = "http://cran.us.r-project.org")
if(!require(arrow)) install.packages("arrow", repos = "http://cran.us.r-project.org") # to read .parquet data
if(!require(tinytex)) install.packages("tinytex", repos = "http://cran.us.r-project.org")


#' 
#' \pagebreak
#' 
#' \tableofcontents
#' 
#' \pagebreak
#' 
#' This is the second part of the Capstone project for the Data Science course by HarvardX, whose tasks is to prepare a Machine Learning project of my own choice, no major indications about the project to choose were given except the expected level of complexity going beyond a simple linear regression model, and the grading constraints.
#' 
#' As a guideline for the project selection two websites with ideas and data sets were provided, [UCI Machine Learning  Repository] (https://archive.ics.uci.edu/ml/index.php) and [Kaggle](https://www.kaggle.com/datasets), however I was concerned about the substance of the project in terms of real application, immediate and direct impact and geographical location.
#' 
#' After a long search for a good theme and data disponibility combination, I was sure that I preferred climate related projects due to the importance and impact of the subject in everyday life, I ended working with information from the capital of Hungary, city of Budapest.
#' 
#' It would have been better to work with more local data, but there is not major data about the small town where I live, however the capital is 10Km away and the best reference obtained.
#' 
#' Some information was provided by the governmental meteorological agency [www.met.hu](www.met.hu) and air quality information obtained from the [European Environment Agency](https://www.eea.europa.eu/en).
#' 
#' I used the information of the station north of the city [https://odp.met.hu/climate/observations_hungary/daily_rain/historical/HABP_1RD_34413_20020101_20231231_hist.zip](https://odp.met.hu/climate/observations_hungary/daily_rain/historical/HABP_1RD_34413_20020101_20231231_hist.zip).
#' 
#' Still after collecting information with direct impact for me, matching the formats and time frame of both data needed a bit of data wrangling that resulted in a short time frame of 10 years of data collected in a daily basis from 2003 January 1st until 2012 December 31st.
#' 
#' Motivation
#' 
#' Air pollution is a variable of global concern nowadays as the world's weather system is getting unstable and new/still dynamically changing atmospheric conditions are affecting all life on earth. There is a systematic self feeding link between pollution and weather as air pollution contributes to the greenhouse effect who at the same time helps decrease the quality of the air.
#' 
#' Contaminated air is causing millions of death around the world, specially for most susceptible population (Classified as Sensitive Population) like children, weak people and elderly, the situation is similar around the world but specially impacting some populated cities in Asia.
#' 
#' The quality of the air of Budapest, with more than 1 500 000 inhabitants, ranks as 256 of 375 cities controlled in Europe with air quality qualified as moderate quality, 13.0 ug/m3 according to measures between 2022 and 2023. More information at [https://www.eea.europa.eu/themes/air/urban-air-quality/european-city-air-quality-viewer](https://www.eea.europa.eu/themes/air/urban-air-quality/european-city-air-quality-viewer).
#' 
#' Moderate air quality qualification is in the range of 10 and to 15 $\mu g/m^3$, the European Union set an annual limit of 25 $\mu g/m^3$.
#' 
## ----echo = FALSE, results = 'asis'----------------------------------------------------------------------------
image = "https://en.wikipedia.org/wiki/File:PM_and_a_human_hair.jpg"
cat(paste0('<center><img src="', image,  '"></center>')) 

#' 
## ----echo = FALSE, results = 'asis'----------------------------------------------------------------------------
image = "https://www.epa.gov/sites/default/files/styles/medium/public/2016-09/pm2.5_scale_graphic-color_2.jpg?itok=AgEKA6PF"
cat(paste0('<center><img src="', image,  '"></center>')) 

#' 
#' As it can be seeing in the following image in the PM10 micrometers category are included several common pollutants, thus we kept it as a good indicator of the air quality.
#' 
#' ![](Airborne-particulate-size-chart.svg.png)
#' 
#' Measures of concentration of PM10 in the air is one of the important indicators of air quality due to the capacity of such small particulates to enter into the human body, a PM10 particle is 1/5 until 1/7 part of a human hair diameter, is reduced to the level of 1/9 of a beach sand grain, such small elements can enter into the body pores and pass to the blood circulation.
#' 
#' There are more dangerous contaminants and smaller particle than PM10, however for the scope of this project it was decided to work with PM10 as a central indicator of quality of the air following level of rain. More about the subject in [Wikipedia](https://en.wikipedia.org/wiki/Particulates).
#' 
#' For the population group sensitive to bad air quality due to physical health conditions it is often advised to avoid outside activities during bad air quality days.
#' 
#' This is why it is important to be able to forecast pollution level rather than just submit warnings after the pollution levels are high.
#' 
#' Rain is known to clean the air from pollutants, "As a raindrop falls through the atmosphere, it can attract tens to hundreds of tiny aerosol particles to its surface before hitting the ground. The process by which droplets and aerosols attract is coagulation, a natural phenomenon that can act to clear the air of pollutants like soot, sulfates, and organic particles." [Source](https://news.mit.edu/2015/rain-drops-attract-aerosols-clean-air-0828)
#' 
#' With actual technology rain can be predicted with somehow good accuracy and some days of anticipation, this is why the intention is to predict a non-predictable variable, air pollution, after a predictable variable, rain.
#' 
#' ## Goal
#' 
#' To generate a model that predicts the expected air quality level in terms of PM10 particulates concentration in the air based on the given rain level in mm.
#' 
#' A machine learning algorithm that, starting from the information about raining prediction provided by the meteorological services, helps predict the levels of PM10 pollutants concentration expected in the air.
#' 
#' With satellite systems, weather information and mathematical prediction models, meteorological services predict and publish the rain forecast, however contamination cannot be predicted this way and is only informed in a historical basis after registers have been collected in several stations. If we use rain predictions in a accurate way we can also have a prediction of the pollution level as well, information that is of importance for the citizens when taking care or preventing exposition to the contamination is important.
#' 
#' \pagebreak
#' 
#' # 1 Data preparation
#' 
#' A match between a significant subject and proper data took several days of internet search and selection, some valuable data could not be retrieved from websites in enough quantity and quality to produce a report, other data was not valuable enough.
#' 
#' Due to local limitations and lack of relevance of the country in the most known databases I have to work with two separate data sets, weather historical registry from the national meteorological service in Hungary [MET](www.met.hu) and pollution historical registry from the [EEA](https://www.eea.europa.eu/en), even this two data sets were not a perfect match and required more data wrangling.
#' 
#' The meteorological data was extensive, well collected with a frequency of daily register from the years 2002 until 2023, you can see more at [https://odp.met.hu/climate/observations_hungary/daily_rain/historical/](https://odp.met.hu/climate/observations_hungary/daily_rain/historical/).
#' 
#' The pollution data from the EEA is somewhat disparate, split into different periods and formats, more difficult to follow and not really well detailed, with a download form that can be found at [https://eeadmz1-downloads-webapp.azurewebsites.net/](https://eeadmz1-downloads-webapp.azurewebsites.net/). The data comes extremely split in several files and not very well identified.
#' 
#' Data is also provided in .parquet format for which the "arrow" package is needed in this project to open the data.
#' 
#' As the time frame of the pollution data is 2003-01-02 until 2013-01-01 in a daily basis the study period was limited to these years, the meteorological data was good enough for this small period and it is still a good base for the project to provide insights into the study and further possible analysis. I also removed extra weather stations of the data set leaving only the capital city, Budapest, into consideration.
#' 
#' The final data went from 1 465 600 rows to 3 654 observations that covered daily registers in the period of 2003 until 2013.
#' 
## ----data preparation, echo=FALSE, results='hide'--------------------------------------------------------------

# loading reads of weather data from 2002 until 2023.
rainRaw <- as.data.frame(str_split(read_lines("HABP_1RD_20020101_20231231_34413.csv"), fixed(";"), simplify = TRUE), strinsAsFactors = FALSE)

# loading reads of PM10 hourly reads from 2003 until 2013
pollutionRaw <- read_parquet("SPO-HU0022A_00005_100.parquet")

# Select only the dates we have in the Pollution table
rainRaw01 <- rainRaw |> filter(V2 >= 20030101 & V2 <= 20121231)
# remove other weather stations as we are interested in one index from the capital city
rainRaw01 <- rainRaw01[(as.numeric(rainRaw01$V1) == 34413),]
# remove unneeded columns
rainRaw01 <- rainRaw01[,(-1)]
rainRaw01 <- rainRaw01[,-c(3:10)]

# After removing unneeded columns original column names V2 corresponds to the date and V3 corresponds to the rain level in mm.

# In the pollutionRaw data we remove unneeded columns
#pollutionRaw01 <- pollutionRaw01[,(-1)]
pollutionRaw01 <- pollutionRaw[,-c(7:11)]

# Finally joined the data in one table to be worked out
colnames(rainRaw01) <- c("Date", "Rain_mm")
workingData <- rainRaw01 |> mutate(PM10 = pollutionRaw01$Value)

# Added proper column names
workingData<- workingData |> mutate(Date =as.numeric(Date),
                                   Rain_mm = as.numeric(Rain_mm),
                                   PM10 = as.numeric(PM10))

# Split data into train and test sets
# test set is 20% of the data
set.seed(1)

test_index <- createDataPartition(y = workingData$PM10, times = 1, p = 0.2, list = FALSE)
train_set <- workingData[-test_index,]
test_set <- workingData[test_index,]

# removing temporal data not needed anymore
rm(rainRaw, test_index, pollutionRaw, pollutionRaw01, rainRaw01)

#' 
#' ## 1.2 Linear regression and other models
#' 
#' # 2 Initial exploration
#' 
#' Minimum values for rain registered by the meteorological authority between 2003 and 2012 is `r round(mean(as.numeric(workingData$Rain_mm)),2)` with maximum of `r max(as.numeric(workingData$Rain_mm))` with standard deviation of `r round(sd(as.numeric(workingData$Rain_mm)),2)`.
#' 
#' Minimum values for PM10 particulate in the air registered between 2003 and 2012 is `r round(mean(as.numeric(workingData$PM10)),2)` with maximum of `r round(max(as.numeric(workingData$PM10)),2)` with standard deviation of `r round(sd(as.numeric(workingData$PM10)),2)`.
#' 
#' ## 2.1 Checking the quality of the data
#' 
#' Final table is a 3 653 observations data frame with 3 numerical variables, a discrete: date, and two continuous: rain in millimeters and pollution PM10 particles in micro grams per cubic meter. Date is formatted as yyyymmdd; year, month day.
#' 
## ----dimension of the data frame-------------------------------------------------------------------------------
dim(workingData)

#' 
#' 
## ----structure of the data frame-------------------------------------------------------------------------------
str(workingData)

#' 
#' 
#' After reducing the data to the matching number of observations between the two data sets I check the quality of the data.
#' 
## ----Checking for empty weather values invalid values----------------------------------------------------------
sum(!complete.cases(workingData))
colSums(is.na(workingData))
sum(is.na(workingData))

#' The resulting data set of the weather reports has not empty nor invalid values.
#' 
## ----head of the data------------------------------------------------------------------------------------------
head(workingData)

#' 
#' Rain level in mm is acts as the predictor and PM10 is the outcome or response that we want to predict for the future (extrapolation).
#' 
#' ## 2.2 Maximum registered rain volume in the period
#' 
## --------------------------------------------------------------------------------------------------------------
max(as.numeric(workingData$Rain_mm))

#' 
#' The maximum registered rain volume was 82 mm registered in 2010-May-15.
#' 
## ----maximum rain row, echo=FALSE------------------------------------------------------------------------------
# Printing the row at which maximum rain had place
workingData[which.max(workingData$Rain_mm),]

#' And a high level of PM10 was reached that day, 32 $\mu g/m^3$.
#' 
#' ## 2.3 Maximum concentration of PM10 per cubic meter in the period
## --------------------------------------------------------------------------------------------------------------
max(as.numeric(workingData$PM10))

#' The maximum registered concentration of PM10 in the study period is 236.1 $\mu$, way above the set level of the European union of 25 $\mu g/m^3$.
#' 
## ----maximum PM10 row, echo=FALSE------------------------------------------------------------------------------
# printing the row at which maximum pollution had place
workingData[which.max(workingData$PM10),]

#' 
#' # 3 Data visualization
#' 
#' We can see rain levels increasing moderately every year from 2003 until 2012.
## ----Rain plot-------------------------------------------------------------------------------------------------

plot(workingData$Date,workingData$Rain_mm, main = "Rain registered between 2003 - 2012", xlab = "Year", ylab = "rain in mm", type="l")

#' 
#' PM10 pollution has, on the other hand, varied from year to year.
#' 
## ----PM10 plot-------------------------------------------------------------------------------------------------
plot(workingData$Date,workingData$PM10,main = "PM10 registered between 2003 - 2012", xlab = "Year", ylab = "PM10 concentration ug/m3", type="l")

#' 
#' For a better calibration of our intuition of the relation between rain level and pollution in the air we shall match both parameters in a graph
#' 
## ----visualization rain and pollution, echo=FALSE--------------------------------------------------------------
p1 <- workingData  |>  
     dplyr::count(Rain_mm) |>  
     ggplot(aes(n)) + 
     geom_histogram(bins = 30, color = "black") + 
     scale_x_log10() + 
     ggtitle("Histogram of Rain")

p2 <- workingData |> 
     dplyr::count(PM10) |> 
     ggplot(aes(n)) +
     geom_histogram(bins = 30, color = "black") +
     scale_x_log10() +
     ggtitle("Histogram of Pollution")
grid.arrange(p1, p2, ncol = 2)

#' However this frequency graph is not depicting the relation of the variables.
#' 
#' When comparing side by side only one year levels we can see the relation is rather poor as pollution goes down during November and December, however some patter can be observe during spring and summer where rain is low and pollution concentration high.
#' 
## ----visualization rain and pollution for 2003, echo=FALSE-----------------------------------------------------

p1 <- workingData |> filter(Date >= 20030101 & Date <= 20031231) |>
  ggplot(aes(Date, Rain_mm)) +
  geom_bar(stat = "identity") +
  scale_x_log10()+
  ggtitle("Graph of Rain 2003")
  
p2 <- workingData |> filter(Date >= 20030101 & Date <= 20031231) |>
  ggplot(aes(Date, PM10)) +
  geom_bar(stat = "identity") +
  scale_x_log10()+
  ggtitle("Graph of Pollution 2003")

grid.arrange(p1, p2, ncol = 2)

#' Preparing the same comparison for 2004 we can see:
#' 
## ----visualization rain and pollution for 2004, echo=FALSE-----------------------------------------------------

p1 <- workingData |> filter(Date >= 20040101 & Date <= 20041231) |>
  ggplot(aes(Date, Rain_mm)) +
  geom_bar(stat = "identity") +
  scale_x_log10() +
  ggtitle("Graph of Rain 2004")
  
p2 <- workingData |> filter(Date >= 20040101 & Date <= 20041231) |>
  ggplot(aes(Date, PM10)) +
  geom_bar(stat = "identity") +
  scale_x_log10() +
  ggtitle("Graph of Pollution 2004")

grid.arrange(p1, p2, ncol = 2)

#' Pollution in January and February 2004, following the previous observed November and December 2003 is also minimal, was is a one off event? Is there a problem with the data? Modeling will need to work with this possible mismatch.
#' 
#' # 4 Modeling the algorithm
#' 
#' ## 4.1 Linear Regression model
#' 
#' The first approach is to use the simple linear regression model of considering that the expected pollution is the mean of the pollution, in order to have a idea of the model possibility and complexity.
#' 
#' <!-- $\hat{y} = \mu$ -->
#' 
## ----simple linear regression, echo=FALSE----------------------------------------------------------------------
y_hat <- mean(train_set$PM10)

rmse01 <- RMSE(train_set$PM10, y_hat)

rmse_results <- tibble(method = "Simple Model", RMSE = rmse01)
rmse_results

#' The simple regression model give a high Root-Mean-Standard-Error, meaning the difference between an expected value and the real value in average is extreme.
#' 
#' This result is due to the high variability in PM10 pollutants concentration between high and low days, making it difficult to predict a level of pollution by just the average contamination level.
#' 
#' This machine learning model presents a challenge in the sense that the prediction is a continuous variable and we are using only one predictor.
#' 
#' ## 4.2 More complex algorithms with caret
#' 
#' Other algorithms were tested as well, however some data quality defect made impossible to run the confusion matrix thus ignoring the accuracy of the models, to avoid models using the Date as one of the predictors it was removed from the training and test sets used.
#' 
#' According to Max Kuhn and Kjell Johnson, Applied Predictive Modeling, 2016:
#' 
#' > There are potential advantages to removing predictors prior to modeling. First, fewer predictors means decreased computational time and complexity. Second, if two predictors are highly correlated, this implies that they are44 3 Data Pre-processing measuring the same underlying information. Removing one should not compromise the performance of the model and might lead to a more parsimonious and interpretable model. Third, some models can be crippled by predictors with degenerate distributions. In these cases, there can be a signiﬁcant improvement in model performance and/or stability without the problematic variables.
#' 
## ----Caret algorithms, echo=FALSE------------------------------------------------------------------------------

# As the model was taking Date as a predictor as well, this was an unexpected and unwanted
# behavior created train and set copies without the Date column

train_set01 <- train_set[,(-1)]
test_set01 <- test_set[,(-1)]

train_glm <- train(PM10 ~. , method = "glm", data = train_set01)
train_kknn <- train(PM10 ~. , method= "kknn" , data = train_set01)
train_rpart <- train(PM10 ~. , method = "rpart", data = train_set01)
train_bagEarth <- train(PM10 ~. , method = "bagEarth", data = train_set01)
train_glmboost <- train(PM10 ~. , method = "glmboost", data = train_set01)

y_hatglm <- predict(train_glm, test_set01, type = "raw")
y_hatkknn <- predict(train_kknn, test_set01, type = "raw")
y_hatrpart <- predict(train_rpart, test_set01, type = "raw")
y_hatrbagEarth <- predict(train_bagEarth, test_set01, type = "raw")
y_hatglmboost <- predict(train_glmboost, test_set01, type = "raw")

# Manual saving of RMSE in variables
rmse02 <- 35.69290
rmse03 <- 23.12566
rmse04 <- 22.88759

rmse_results <- bind_rows(rmse_results, tibble(method = "kknn", RMSE = rmse02))
rmse_results <- bind_rows(rmse_results, tibble(method = "rpart", RMSE = rmse03))
rmse_results <- bind_rows(rmse_results, tibble(method = "bagEarth", RMSE = rmse04))
rmse_results

#' After testing 5 different algorithms with not noticeable difference in their results: glm, kknn, rpart, bagEarth and glmboost, the more accurate were kept: kknn, rpart and bagEarth.
#' 
#' From the last two we kept bagEarth with RMSE of 23.06.
#' 
## ----bagEarth performance--------------------------------------------------------------------------------------
train_bagEarth$finalModel
ggplot(train_bagEarth, highlight = TRUE)

#' Some other models were tested with errors, by example Loess, however to avoid an Error Type III by loosing sight of the goal of the project and focusing in the technicalities, we keep the previously mentioned.
#' 
#' # 5 Results
#' 
#' Working with real world data that comes from different collections determine the possibilities of the algorithm. In the actual project, although after data wrangling the format and time coverage was stable, having a short period of 10 years and only one predictor impacted the algorithm accuracy negatively.
#' 
#' The accuracy measures in term of RMSE or error from the prediction of complex algorithm of caret package did not really improve much over the simple mean of the outcome, leaving clear that pattern between rain and pollution was not enough, pollution is too variable and more data is needed.
#' 
#' One consideration that was out of the scope of this essay is the time delay between rains and pollution levels, worth to be further investigated in search of possible patterns that cannot be seeing when checking one by one rain and pollution in the same dates.
#' 
#' Still intuition indicates rain and clean air have a relation that, might not be direct but through any other ignored elements that link both the pretended predictor and outcome. Although rain is a very commonly used weather indicator, there is plenty of many other indicators like wind, humidity, atmospheric pressure that can be added to the model for future investigations.
#' 
#' Still this project never pretended to state that low pollution was caused by rain levels but, that my be a causality relation between both events.
#' 
#' Various techniques were used for the present project that can be resumed in the following:
#' 
## ----Final results for the results with code-------------------------------------------------------------------
rmse_results|>  knitr::kable()

#' 
#' The accuracy in terms of the error from the prediction of the algorithm to the real value is not satisfactory, thus it was necessary to try several models in search of a better result, internet search of guidance in this respect did not really helped.
#' 
#' Thus this project leads to the following conclusions.
#' 
#' # 6 Conclusion
#' 
#' Weather related prediction has long proved to be a difficult subject due to various factors, mainly the complexity of weather as a system of different elements and their relations, including human activity.
#' 
#' The main goal in this project was to predict a pollution variable, PM10 concentration in the air, starting from the prediction of a weather variable, rain, in the city of Budapest, Hungary.
#' 
#' The availability of data was a challenge and having a final subset of data required some work.
#' 
#' However the project gives light to other paths into more investigation and different approach to the same goal given its impact con everyday life on earth. The living, economical and health effect of being able to predict pollution and establish sound prevention alarms is worth the investigation.
#' 
#' New approaches can include, between others, a check of the time delay between rain and pollution levels, the inclusion of other predictors into the model, the test of the evaluation of other pollutants different from PM10 and the test of other algorithm that might be more suitable for weather related projects.
